create
    definer = root@localhost procedure update_autocare()
BEGIN
		DECLARE finished INTEGER DEFAULT 0;
		declare autocare integer;
        DEClARE autocare_cursor CURSOR FOR  SELECT ID_Autocar FROM autocare;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
  		
	open autocare_cursor;
	autocare_loop: loop
		fetch autocare_cursor into autocare;
    
		IF finished = 1 THEN 
		LEAVE autocare_loop;
		END IF;
		set @km=(select sum(distanta_totala) from sejur where id_autocar=autocare and data_sfarsit<current_date);
       if(@km is null) then set @km=0;
       end if;
		update autocare set km_parcursi=@km where id_autocar=autocare;
        end loop autocare_loop;


END;

