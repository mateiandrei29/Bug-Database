create definer = root@localhost trigger update_locuri
    after insert
    on contractare_sejur
    for each row
BEGIN
    
		update sejur set nr_locuri=nr_locuri-new.nrsejururi where id_sejur=new.id_sejur;
       
	END;

