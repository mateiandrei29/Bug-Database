create definer = root@localhost trigger data_mesaje
    before insert
    on mesaje
    for each row
BEGIN
    
		set new.data_expediere=current_timestamp();
        
       
	END;

