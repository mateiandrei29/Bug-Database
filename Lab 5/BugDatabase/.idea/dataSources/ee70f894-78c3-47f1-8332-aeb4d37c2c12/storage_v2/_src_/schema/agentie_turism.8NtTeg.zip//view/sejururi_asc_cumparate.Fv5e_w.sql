create definer = root@localhost view sejururi_asc_cumparate as
select `agentie_turism`.`sejur`.`ID_Sejur`        AS `ID_Sejur`,
       `agentie_turism`.`sejur`.`ID_Autocar`      AS `ID_Autocar`,
       `agentie_turism`.`sejur`.`Sofer1`          AS `Sofer1`,
       `agentie_turism`.`sejur`.`Sofer2`          AS `Sofer2`,
       `agentie_turism`.`sejur`.`Ghid`            AS `Ghid`,
       `agentie_turism`.`sejur`.`Data_start`      AS `Data_start`,
       `agentie_turism`.`sejur`.`Data_sfarsit`    AS `Data_sfarsit`,
       `agentie_turism`.`sejur`.`Distanta_totala` AS `Distanta_totala`,
       `agentie_turism`.`sejur`.`Pret_transport`  AS `Pret_transport`,
       `agentie_turism`.`sejur`.`Nr_locuri`       AS `Nr_locuri`,
       `agentie_turism`.`sejur`.`Durata`          AS `Durata`
from `agentie_turism`.`sejur`
where (`agentie_turism`.`sejur`.`Data_start` > curdate())
order by (case
              when `agentie_turism`.`sejur`.`ID_Sejur` in
                   (select `agentie_turism`.`contractare_sejur`.`ID_Sejur` from `agentie_turism`.`contractare_sejur`)
                  then (select count(`agentie_turism`.`contractare_sejur`.`ID_Contract`)
                        from `agentie_turism`.`contractare_sejur`
                        where (`agentie_turism`.`contractare_sejur`.`ID_Sejur` = `agentie_turism`.`sejur`.`ID_Sejur`))
              when (not (`agentie_turism`.`sejur`.`ID_Sejur` in (select `agentie_turism`.`contractare_sejur`.`ID_Sejur`
                                                                 from `agentie_turism`.`contractare_sejur`)))
                  then 0 end) desc;

