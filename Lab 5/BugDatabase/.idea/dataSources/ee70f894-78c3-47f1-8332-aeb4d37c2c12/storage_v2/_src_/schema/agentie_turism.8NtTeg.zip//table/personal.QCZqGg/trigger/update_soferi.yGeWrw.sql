create definer = root@localhost trigger update_soferi
    before update
    on personal
    for each row
BEGIN
    
  	if (OLD.functie='sofer' AND NEW.FUNCTIE!='SOFER') then
		DELETE FROM soferi WHERE ID_SOFER=NEW.ID_PERSONAL;
	end if;
    
	if (NEW.FUNCTIE='SOFER' AND OLD.functie!='sofer' ) then
		insert into soferi(ID_Sofer,accidente,nrcurse) values (new.id_personal,0,0);
	end if;
    
	END;

