create
    definer = root@localhost procedure Cumparare_Sejur(IN _ID_Utilizator int, IN _ID_Sejur int, IN _NrSejururi int,
                                                       IN string_hoteluri varchar(300))
begin
	
	declare locuri integer;
    declare durata_rezervare integer;
    declare data_start_rezervare,data_sfarsit_rezervare datetime;
	declare i,puncte_fidelitate_user,pret integer default 0;
	declare nr_hoteluri integer;
    set nr_hoteluri=(select count(id_sejur) from traseu where id_sejur=_id_sejur);
    set nr_hoteluri=nr_hoteluri-1;
	set @data_start = (select data_start from sejur where id_sejur=_id_sejur);
    set @dif = timestampdiff(day,current_date(), @data_start);
    
    if (@dif < 0) then select "Oferta expirata! " as Mesaj;
    else
		set locuri = (select nr_locuri from sejur where id_sejur=_id_sejur);
		if(locuri>=_nrsejururi) then
			insert into contractare_sejur(id_utilizator,id_Sejur,nrsejururi) values
            (_id_utilizator,_id_sejur,_nrsejururi);    
           set @contract= (select max(id_contract) from contractare_sejur);
           
           
            loop_insert: loop
			set i=i+1;
            if i=nr_hoteluri+1 then
				leave loop_insert;
			end if;
				
                set @hotel = SPLIT_STRING(string_hoteluri,',',i) ;
				
                    
                    #verific daca @hotel e in orasu corespunzator
			
            set @verifica_hotel=null;
            
            set @verifica_hotel=(select id_hotel from traseu,hoteluri where traseu.oras2=hoteluri.oras and traseu.id_sejur=_id_sejur and id_hotel=@hotel);
            
            if (@verifica_hotel is null) then
            select "Hotelul nu este din orasul destinatie" as Mesaj;
            leave loop_insert;
            else
            
			set data_start_rezervare = 
            (select traseu.data_sfarsit
            from traseu,hoteluri
            where traseu.id_sejur=_id_sejur
            and hoteluri.id_hotel=@hotel
            and traseu.oras2=hoteluri.oras
            group by traseu.data_start);                  
                    
				
			set data_sfarsit_rezervare = 
			(select traseu.data_start
            from traseu,hoteluri
            where traseu.id_sejur=_id_sejur
            and hoteluri.id_hotel=@hotel
            and traseu.oras1=hoteluri.oras
            group by traseu.data_start);
                   
                    
			set @zi_start = dayofyear(data_start_rezervare);
			set @zi_sfarsit = dayofyear(data_sfarsit_rezervare);
			            
            set durata_rezervare = @zi_sfarsit - @zi_start;
            if (durata_rezervare < 0 ) then
            #inseamna ca prima data este in alt an fata de a doua
				set durata_rezervare = durata_rezervare + 365;
			end if;
			
			
            
            set @pret_rezervare = (select pret_pers_noapte from hoteluri where id_hotel=@hotel);
 
			if(durata_rezervare<=1) then
		set @pret = @pret_rezervare;
        else
		set @pret = @pret_rezervare * durata_rezervare;
			end if;

                    
                    
			insert into rezervare_hotel(id_contract,ID_Hotel,data_start,data_Sfarsit,pret,durata) 
            values (@contract,@hotel,data_start_rezervare,data_sfarsit_rezervare,@pret,durata_rezervare);
			update contractare_sejur set pret_pers=pret_pers+@pret where id_contract=@contract;
                    
        end if;
        end loop;
		if(@verifica_hotel is not null) then
		set @pret_transport=(select pret_transport from sejur where id_sejur=_id_sejur);
		update contractare_sejur set pret_pers=pret_pers+@pret_transport where id_contract=@contract;
        set pret=(select pret_pers from contractare_sejur where id_contract=@contract)*_nrsejururi;
		set puncte_fidelitate_user =(select puncte_fidelitate from utilizatori where id_utilizator=_id_utilizator);
        if(puncte_fidelitate_user>=pret) then
        update contractare_Sejur set reduceri=pret where id_contract=@contract;
        update contractare_Sejur set pret_final=0 where id_contract=@contract;
        update utilizatori set puncte_fidelitate = puncte_fidelitate_user - pret where ID_Utilizator=_ID_Utilizator;
        else
        update contractare_Sejur set reduceri=puncte_fidelitate_user where id_contract=@contract;
        update contractare_Sejur set pret_final=pret-puncte_fidelitate_user where id_contract=@contract;
        
        update utilizatori set puncte_fidelitate = (pret-puncte_fidelitate_user) / 10 where ID_Utilizator=_ID_Utilizator;
        
           end if;
			
        select "Succes" as Mesaj;
        else delete from contractare_sejur where id_contract=@contract;
        end if;
		else select "Nu mai exista locuri" as Mesaj;
        end if;
	end if;
    
    
  end;

