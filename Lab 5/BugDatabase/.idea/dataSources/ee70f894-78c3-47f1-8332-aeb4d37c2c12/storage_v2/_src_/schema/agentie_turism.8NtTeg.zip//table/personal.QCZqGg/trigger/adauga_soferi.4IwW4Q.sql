create definer = root@localhost trigger adauga_soferi
    after insert
    on personal
    for each row
BEGIN
  	if (new.functie='sofer') then
		insert into soferi(ID_Sofer,accidente,nrcurse) values (new.id_personal,0,0);
	end if;
    
	END;

