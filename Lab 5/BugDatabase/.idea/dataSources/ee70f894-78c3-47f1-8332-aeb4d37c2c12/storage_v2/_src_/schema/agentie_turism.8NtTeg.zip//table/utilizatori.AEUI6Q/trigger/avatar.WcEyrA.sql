create definer = root@localhost trigger avatar
    before insert
    on utilizatori
    for each row
BEGIN
    
	if(new.sex="F" and (new.avatar="" or new.avatar is null)) then set new.avatar="noimage_female.jpg";
    end if;
	if(new.sex="M" and (new.avatar="" or new.avatar is null)) then set new.avatar="noimage_male.jpg";
	end if;
       
	END;

