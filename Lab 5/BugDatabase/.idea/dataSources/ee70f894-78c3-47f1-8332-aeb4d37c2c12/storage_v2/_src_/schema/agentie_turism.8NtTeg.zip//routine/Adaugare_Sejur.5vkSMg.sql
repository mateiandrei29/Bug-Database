create
    definer = root@localhost procedure Adaugare_Sejur(IN _id_autocar int, IN _id_sofer1 int, IN _id_sofer2 int,
                                                      IN _id_ghid int, IN nr_trasee int, IN string_orase1 varchar(300),
                                                      IN string_orase2 varchar(300), IN string_data_start varchar(300),
                                                      IN string_data_sfarsit varchar(300),
                                                      IN string_distante varchar(300))
begin
			declare i integer default 0;
        # VERIFIC  daca autocarul imi mai apare in perioada aia in alt sejur
        # avem nevoie de datele de start si final a cursei, deci folosim functia split
        
		set @verificare_autocar = null;
        set @verificare_sofer1 = null;
		set @verificare_sofer2 = null;
		set @verificare_ghid = null;
		set @verificare_concediu1 = null;
		set @verificare_concediu2 = null;
		set @verificare_concediu3 = null;
		set @data_start = SPLIT_STRING(string_data_start,',',1) ;
		set @data_sfarsit = SPLIT_STRING(string_data_sfarsit,',',nr_trasee);
       
        set @verificare_autocar=(select id_autocar from sejur where id_autocar=_id_autocar and not (@data_start > data_sfarsit or @data_sfarsit < data_start));
        set @verificare_sofer1= (select sofer1 from sejur where sofer1=_id_sofer1 and not (@data_start > data_sfarsit or @data_sfarsit < data_start));
        set @verificare_sofer2=(select sofer2 from sejur where sofer2=_id_sofer2 and not (@data_start > data_sfarsit or @data_sfarsit < data_start));
		set @verificare_sofer1=(select sofer1 from sejur where sofer2=_id_sofer1 and not (@data_start > data_sfarsit or @data_sfarsit < data_start));
        set @verificare_sofer2=(select sofer2 from sejur where sofer1=_id_sofer2 and not (@data_start > data_sfarsit or @data_sfarsit < data_start));
        set @verificare_ghid=(select ghid from sejur where ghid=_id_ghid and not (@data_start > data_sfarsit or @data_sfarsit < data_start));
        
        #verific daca soferii nu sunt in concediu
        set @verificare_concediu1=(select id_personal from concedii where id_personal=_id_sofer1 and not(@data_start > data_sfarsit or @data_sfarsit < data_start));
        set @verificare_concediu2=(select id_personal from concedii where id_personal=_id_sofer2 and not(@data_start > data_sfarsit or @data_sfarsit < data_start));
        set @verificare_concediu3=(select id_personal from concedii where id_personal=_id_ghid and not(@data_start > data_sfarsit or @data_sfarsit < data_start));
        
        
               
        if (@verificare_autocar is null and @verificare_sofer1 is null and @verificare_sofer2 is null) then
		if (@verificare_concediu1 is null and @verificare_concediu2 is null) then
			insert into sejur (id_autocar,sofer1,sofer2,ghid) values (_id_autocar,_id_sofer1,_id_sofer2,_id_ghid);
			set @id_sejur = (select max(id_sejur) from sejur); 
			     
        loop_insert: loop
			set i=i+1;
            if i=nr_trasee+1 then
				leave loop_insert;
			end if;
				set @oras1 = SPLIT_STRING(string_orase1,',',i) ;
                set @oras2 = SPLIT_STRING(string_orase2,',',i) ;
                set @date1 = SPLIT_STRING(string_data_start,',',i) ;
                set @date2 = SPLIT_STRING(string_data_sfarsit,',',i) ;
                set @distanta = SPLIT_STRING(string_distante,',',i) ;
				
				set @durata = timestampdiff(second, @date1, @date2);
                if(@durata < 0) then 
                delete from sejur where id_sejur=@id_sejur;     
                select "Perioada specificata nu este valida (este descrescatoare)! " as Mesaj;
                leave loop_insert;
				else
                
				insert into traseu(id_sejur,oras1,oras2,data_start,data_sfarsit,`distanta(km)`) values
				(@id_sejur,@oras1,@oras2,@date1,@date2,@distanta);
               
				
               

				end if;
        
        end loop;
        if(@durata > 0) then
        set @locuri=(select numar_locuri from autocare where id_autocar=_id_autocar);
        update sejur set nr_locuri=@locuri where id_sejur=@id_Sejur;
		select "Succes" as Mesaj;
        end if;
        
        else select "Unul dintre soferi sau ghidul este in concediu in perioada specificata" as Mesaj;
        end if;
        
        else select "Autocarul, soferii sau ghidul nu sunt disponibili in perioada specificata! " as Mesaj;
        end if;
        
      
        
  
	
  end;

