create definer = root@localhost trigger data_comentarii
    before insert
    on comentarii
    for each row
BEGIN
    
		set new.data_postarii=current_timestamp();
        
       
	END;

