create definer = root@localhost view clienti as
select `agentie_turism`.`utilizatori`.`Nume`                                     AS `Nume`,
       `agentie_turism`.`utilizatori`.`Prenume`                                  AS `Prenume`,
       `agentie_turism`.`utilizatori`.`Puncte_Fidelitate`                        AS `Puncte Fidelitate`,
       (case
            when `agentie_turism`.`utilizatori`.`ID_Utilizator` in
                 (select `agentie_turism`.`contractare_sejur`.`ID_Utilizator` from `agentie_turism`.`contractare_sejur`)
                then (select sum(`agentie_turism`.`contractare_sejur`.`Pret_Final`)
                      from `agentie_turism`.`contractare_sejur`
                      where (`agentie_turism`.`contractare_sejur`.`ID_Utilizator` =
                             `agentie_turism`.`utilizatori`.`ID_Utilizator`))
            when (not (`agentie_turism`.`utilizatori`.`ID_Utilizator` in
                       (select `agentie_turism`.`contractare_sejur`.`ID_Utilizator`
                        from `agentie_turism`.`contractare_sejur`))) then 0 end) AS `Total Cumparaturi`,
       (case
            when `agentie_turism`.`utilizatori`.`ID_Utilizator` in
                 (select `agentie_turism`.`contractare_sejur`.`ID_Utilizator` from `agentie_turism`.`contractare_sejur`)
                then (select sum(`agentie_turism`.`contractare_sejur`.`Reduceri`)
                      from `agentie_turism`.`contractare_sejur`
                      where (`agentie_turism`.`contractare_sejur`.`ID_Utilizator` =
                             `agentie_turism`.`utilizatori`.`ID_Utilizator`))
            when (not (`agentie_turism`.`utilizatori`.`ID_Utilizator` in
                       (select `agentie_turism`.`contractare_sejur`.`ID_Utilizator`
                        from `agentie_turism`.`contractare_sejur`))) then 0 end) AS `Total Reduceri`
from `agentie_turism`.`utilizatori`
where (`agentie_turism`.`utilizatori`.`Admin` = 0)
order by `Total Cumparaturi` desc;

