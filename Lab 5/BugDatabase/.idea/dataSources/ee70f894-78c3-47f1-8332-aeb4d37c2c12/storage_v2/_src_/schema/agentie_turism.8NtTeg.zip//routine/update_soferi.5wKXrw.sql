create
    definer = root@localhost procedure update_soferi()
BEGIN
		DECLARE finished INTEGER DEFAULT 0;
		declare soferi integer;
        DEClARE soferi_cursor CURSOR FOR  SELECT ID_Sofer FROM soferi;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

	open soferi_cursor;
	soferi_loop: loop
		fetch soferi_cursor into soferi;
    
		IF finished = 1 THEN 
		LEAVE soferi_loop;
		END IF;
        set @sof1=(select count(sofer1) from sejur where sofer1=soferi and data_sfarsit<current_date);
        set @sof2=(select count(sofer2) from sejur where sofer2=soferi and data_sfarsit<current_date);
        update soferi set nrcurse=@sof1+@sof2 where id_sofer=soferi;
        
        end loop soferi_loop;


END;

