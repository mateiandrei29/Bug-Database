create definer = root@localhost trigger modificari_sejur
    before insert
    on traseu
    for each row
BEGIN

		declare sejur_data_start,sejur_data_sfarsit,sej_start,sej_sfarsit datetime;
        declare durata_zile integer default 0;
        set sejur_data_start = (select data_start from sejur where new.id_sejur=id_sejur);
		set sejur_data_sfarsit = (select data_sfarsit from sejur where new.id_sejur=id_sejur);
        update sejur set distanta_totala=distanta_totala + new.`distanta(km)` where id_sejur=new.id_sejur;
        update sejur set pret_transport=distanta_totala * 0.1 where id_sejur=new.id_sejur;
        
        if(sejur_data_start is null) then
        set sejur_data_start = '2020/12/31'; ## setam data de start la o data foarte mare ca mai apoi la comparatie sa fie luat ce trebuie
        end if;
        
		if(sejur_data_sfarsit is null) then
        set sejur_data_sfarsit = '2000/01/01'; ## setam data de start la o data mica (data curenta) ca mai apoi la comparatie sa fie luat ce trebuie
        end if;
        
        if(sejur_data_start > new.data_start) then
        update sejur set data_start=new.data_start where id_sejur=new.id_sejur;
        end if;
        
        if (sejur_data_sfarsit < new.data_sfarsit) then
        update sejur set data_sfarsit=new.data_sfarsit where id_sejur=new.id_sejur;
        end if;
		
        set sej_start=(select data_start from sejur where id_sejur=new.id_sejur);
        set sej_sfarsit=(select data_sfarsit from sejur where id_sejur=new.id_sejur);
        set durata_zile=timestampdiff(day,sej_start,sej_sfarsit);
		update sejur set durata=durata_zile where id_sejur=new.id_sejur;
        
	END;

