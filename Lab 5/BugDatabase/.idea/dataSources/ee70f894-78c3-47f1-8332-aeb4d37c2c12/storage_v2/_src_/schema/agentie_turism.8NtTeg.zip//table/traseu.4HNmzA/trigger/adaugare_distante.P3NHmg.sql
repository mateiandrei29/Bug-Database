create definer = root@localhost trigger adaugare_distante
    after insert
    on traseu
    for each row
BEGIN
		DECLARE finished INTEGER DEFAULT 0;
		declare distante integer;
        DEClARE distante_cursor CURSOR FOR  SELECT ID_Distanta FROM distante;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;

	set @ok=1;
	open distante_cursor;
	distante_loop: loop
		fetch distante_cursor into distante;
    
		IF finished = 1 THEN 
		LEAVE distante_loop;
		END IF;
        
        set @oras1 = (select oras1 from distante where id_distanta=distante);
        set @oras2 = (select oras2 from distante where id_distanta=distante);
        
        if((new.oras1=@oras1 and new.oras2=@oras2) or (new.oras2=@oras1 and new. oras1=@oras2)) then
			set @ok=0;
            leave distante_loop;
        end if;
        
        end loop distante_loop;

		if(@ok=1) then
		insert into distante(oras1,oras2,distanta) values (new.oras1,new.oras2,new.`distanta(km)`);
		end if;
        
        
	END;

