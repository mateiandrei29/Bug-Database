create definer = root@localhost view angajati as
select `agentie_turism`.`personal`.`ID_Personal` AS `ID_Personal`,
       `agentie_turism`.`personal`.`Nume`        AS `Nume`,
       `agentie_turism`.`personal`.`Prenume`     AS `Prenume`,
       `agentie_turism`.`personal`.`Adresa`      AS `Adresa`,
       `agentie_turism`.`personal`.`Telefon`     AS `Telefon`,
       `agentie_turism`.`personal`.`Functie`     AS `Functie`,
       `agentie_turism`.`personal`.`Salariu`     AS `Salariu`,
       `agentie_turism`.`departament`.`Denumire` AS `Departament`,
       `agentie_turism`.`sediu`.`Denumire`       AS `Sediu`
from ((`agentie_turism`.`personal` join `agentie_turism`.`departament`)
         join `agentie_turism`.`sediu`)
where ((`agentie_turism`.`personal`.`ID_Sediu` = `agentie_turism`.`sediu`.`ID_Sediu`) and
       (`agentie_turism`.`departament`.`ID_Departament` = `agentie_turism`.`personal`.`ID_Departament`));

