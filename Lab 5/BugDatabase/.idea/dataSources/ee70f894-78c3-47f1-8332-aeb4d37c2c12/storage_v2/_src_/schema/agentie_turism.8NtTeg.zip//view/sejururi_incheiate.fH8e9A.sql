create definer = root@localhost view sejururi_incheiate as
select `agentie_turism`.`sejur`.`ID_Sejur`        AS `ID_Sejur`,
       `agentie_turism`.`autocare`.`Marca`        AS `Marca`,
       `agentie_turism`.`autocare`.`Model`        AS `Model`,
       `agentie_turism`.`sejur`.`Data_start`      AS `Data_start`,
       `agentie_turism`.`sejur`.`Data_sfarsit`    AS `Data_sfarsit`,
       `p1`.`Nume`                                AS `Nume1`,
       `p1`.`Prenume`                             AS `Prenume1`,
       `p2`.`Nume`                                AS `Nume2`,
       `p2`.`Prenume`                             AS `Prenume2`,
       `p3`.`Nume`                                AS `Nume3`,
       `p3`.`Prenume`                             AS `Prenume3`,
       `agentie_turism`.`sejur`.`Distanta_totala` AS `Distanta_totala`,
       `agentie_turism`.`sediu`.`Denumire`        AS `Sediu`,
       `agentie_turism`.`sejur`.`Pret_transport`  AS `Pret_transport`
from (((((`agentie_turism`.`sejur` join `agentie_turism`.`autocare`) join `agentie_turism`.`personal` `p1`) join `agentie_turism`.`personal` `p2`) join `agentie_turism`.`personal` `p3`)
         join `agentie_turism`.`sediu`)
where ((`agentie_turism`.`sejur`.`Data_sfarsit` < curdate()) and
       (`agentie_turism`.`sejur`.`Sofer1` = `p1`.`ID_Personal`) and
       (`agentie_turism`.`sejur`.`Sofer2` = `p2`.`ID_Personal`) and
       (`agentie_turism`.`sejur`.`Ghid` = `p3`.`ID_Personal`) and
       (`agentie_turism`.`sejur`.`ID_Autocar` = `agentie_turism`.`autocare`.`ID_Autocar`) and
       (`agentie_turism`.`autocare`.`ID_Sediu` = `agentie_turism`.`sediu`.`ID_Sediu`));

